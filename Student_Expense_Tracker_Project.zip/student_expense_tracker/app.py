"""
Student Expense Tracker - a Flask web application.

Features
--------
* User registration / login (hashed passwords, session based)
* Add, edit, delete expenses (title, amount, category, date, note)
* Monthly budget with remaining-balance tracking
* Dashboard with category breakdown and 6-month trend charts
* Search + filter (month, category) and CSV export
* CSRF protection on every POST request
"""
import csv
import io
import os
import secrets
import sqlite3
from datetime import date, datetime
from functools import wraps

from flask import (Flask, Response, abort, flash, g, redirect,
                   render_template, request, session, url_for)
from werkzeug.security import check_password_hash, generate_password_hash

BASE_DIR = os.path.abspath(os.path.dirname(__file__))

CATEGORIES = [
    "Food", "Transport", "Books & Stationery", "Rent & Hostel",
    "Entertainment", "Health", "Recharge & Bills", "Shopping", "Other",
]

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "change-this-secret-key")
app.config["DATABASE"] = os.path.join(BASE_DIR, "expenses.db")

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    username      TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    created_at    TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS expenses (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title      TEXT NOT NULL,
    amount     REAL NOT NULL CHECK (amount > 0),
    category   TEXT NOT NULL,
    spent_on   TEXT NOT NULL,           -- ISO date YYYY-MM-DD
    note       TEXT DEFAULT '',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_expenses_user_date ON expenses(user_id, spent_on);
CREATE TABLE IF NOT EXISTS budgets (
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    month   TEXT NOT NULL,              -- YYYY-MM
    amount  REAL NOT NULL CHECK (amount >= 0),
    PRIMARY KEY (user_id, month)
);
"""


# --------------------------------------------------------------------------
# Database helpers
# --------------------------------------------------------------------------
def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(app.config["DATABASE"])
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(_exc=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    db = get_db()
    db.executescript(SCHEMA)
    db.commit()


# --------------------------------------------------------------------------
# Security: CSRF + login
# --------------------------------------------------------------------------
@app.before_request
def csrf_protect():
    if request.method == "POST":
        token = session.get("_csrf")
        if not token or not secrets.compare_digest(token, request.form.get("_csrf", "")):
            abort(400, "Invalid or missing CSRF token. Refresh the page and try again.")


@app.context_processor
def inject_globals():
    if "_csrf" not in session:
        session["_csrf"] = secrets.token_hex(16)
    return {
        "csrf_token": session["_csrf"],
        "categories": CATEGORIES,
        "current_user": session.get("username"),
        "today": date.today().isoformat(),
    }


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if "user_id" not in session:
            flash("Please log in to continue.", "info")
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped


# --------------------------------------------------------------------------
# Utility functions
# --------------------------------------------------------------------------
def parse_month(value):
    """Return a valid 'YYYY-MM' string (defaults to the current month)."""
    try:
        return datetime.strptime(value or "", "%Y-%m").strftime("%Y-%m")
    except ValueError:
        return date.today().strftime("%Y-%m")


def month_shift(month, delta):
    year, mon = map(int, month.split("-"))
    idx = year * 12 + (mon - 1) + delta
    return f"{idx // 12:04d}-{idx % 12 + 1:02d}"


def month_label(month):
    return datetime.strptime(month, "%Y-%m").strftime("%b %Y")


def validate_expense(form):
    """Validate expense form data. Returns (clean_dict, error_message)."""
    title = form.get("title", "").strip()
    category = form.get("category", "")
    note = form.get("note", "").strip()[:300]
    spent_on = form.get("spent_on", "")

    if not title or len(title) > 80:
        return None, "Title is required (max 80 characters)."
    try:
        amount = round(float(form.get("amount", "")), 2)
    except ValueError:
        return None, "Amount must be a number."
    if not (0 < amount <= 10_000_000):
        return None, "Amount must be greater than 0 and at most 1,00,00,000."
    if category not in CATEGORIES:
        return None, "Please choose a valid category."
    try:
        datetime.strptime(spent_on, "%Y-%m-%d")
    except ValueError:
        return None, "Please enter a valid date."
    return {"title": title, "amount": amount, "category": category,
            "spent_on": spent_on, "note": note}, None


def filtered_expenses(user_id, args):
    """Build the filtered expense query used by list view and CSV export."""
    month = args.get("month", "")
    category = args.get("category", "")
    q = args.get("q", "").strip()

    sql = "SELECT * FROM expenses WHERE user_id = ?"
    params = [user_id]
    if month:
        month = parse_month(month)
        sql += " AND substr(spent_on, 1, 7) = ?"
        params.append(month)
    if category in CATEGORIES:
        sql += " AND category = ?"
        params.append(category)
    if q:
        sql += " AND (title LIKE ? OR note LIKE ?)"
        params += [f"%{q}%", f"%{q}%"]
    sql += " ORDER BY spent_on DESC, id DESC"
    rows = get_db().execute(sql, params).fetchall()
    return rows, {"month": month, "category": category, "q": q}


# --------------------------------------------------------------------------
# Authentication routes
# --------------------------------------------------------------------------
@app.route("/")
def index():
    return redirect(url_for("dashboard" if "user_id" in session else "login"))


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username", "").strip().lower()
        password = request.form.get("password", "")
        confirm = request.form.get("confirm", "")
        error = None
        if not (3 <= len(username) <= 30) or not username.replace("_", "").isalnum():
            error = "Username must be 3-30 characters (letters, numbers, underscore)."
        elif len(password) < 6:
            error = "Password must be at least 6 characters."
        elif password != confirm:
            error = "Passwords do not match."
        else:
            db = get_db()
            try:
                db.execute("INSERT INTO users (username, password_hash) VALUES (?, ?)",
                           (username, generate_password_hash(password)))
                db.commit()
            except sqlite3.IntegrityError:
                error = "That username is already taken."
        if error:
            flash(error, "error")
        else:
            flash("Account created. Please log in.", "success")
            return redirect(url_for("login"))
    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip().lower()
        password = request.form.get("password", "")
        user = get_db().execute("SELECT * FROM users WHERE username = ?",
                                (username,)).fetchone()
        if user and check_password_hash(user["password_hash"], password):
            session.clear()
            session["user_id"] = user["id"]
            session["username"] = user["username"]
            return redirect(url_for("dashboard"))
        flash("Invalid username or password.", "error")
    return render_template("login.html")


@app.route("/logout", methods=["POST"])
def logout():
    session.clear()
    flash("You have been logged out.", "info")
    return redirect(url_for("login"))


# --------------------------------------------------------------------------
# Dashboard
# --------------------------------------------------------------------------
@app.route("/dashboard")
@login_required
def dashboard():
    uid = session["user_id"]
    db = get_db()
    month = parse_month(request.args.get("month"))

    total = db.execute(
        "SELECT COALESCE(SUM(amount), 0) FROM expenses "
        "WHERE user_id = ? AND substr(spent_on, 1, 7) = ?", (uid, month)).fetchone()[0]
    count = db.execute(
        "SELECT COUNT(*) FROM expenses WHERE user_id = ? AND substr(spent_on, 1, 7) = ?",
        (uid, month)).fetchone()[0]

    by_category = db.execute(
        "SELECT category, SUM(amount) AS total FROM expenses "
        "WHERE user_id = ? AND substr(spent_on, 1, 7) = ? "
        "GROUP BY category ORDER BY total DESC", (uid, month)).fetchall()

    # last 6 months trend (including selected month)
    months = [month_shift(month, -i) for i in range(5, -1, -1)]
    trend_rows = db.execute(
        "SELECT substr(spent_on, 1, 7) AS m, SUM(amount) AS total FROM expenses "
        "WHERE user_id = ? AND substr(spent_on, 1, 7) BETWEEN ? AND ? GROUP BY m",
        (uid, months[0], months[-1])).fetchall()
    trend_map = {r["m"]: r["total"] for r in trend_rows}

    budget_row = db.execute("SELECT amount FROM budgets WHERE user_id = ? AND month = ?",
                            (uid, month)).fetchone()
    budget = budget_row["amount"] if budget_row else None
    percent = min(round(total / budget * 100), 100) if budget else 0

    recent = db.execute(
        "SELECT * FROM expenses WHERE user_id = ? AND substr(spent_on, 1, 7) = ? "
        "ORDER BY spent_on DESC, id DESC LIMIT 5", (uid, month)).fetchall()

    days_in_data = max(date.today().day if month == date.today().strftime("%Y-%m") else 30, 1)
    return render_template(
        "dashboard.html",
        month=month, month_text=month_label(month),
        prev_month=month_shift(month, -1), next_month=month_shift(month, 1),
        total=total, count=count, budget=budget, percent=percent,
        remaining=(budget - total) if budget is not None else None,
        daily_avg=total / days_in_data,
        by_category=[dict(r) for r in by_category],
        trend_labels=[month_label(m) for m in months],
        trend_values=[round(trend_map.get(m, 0), 2) for m in months],
        recent=recent,
    )


@app.route("/budget", methods=["POST"])
@login_required
def set_budget():
    month = parse_month(request.form.get("month"))
    try:
        amount = round(float(request.form.get("amount", "")), 2)
        if amount < 0 or amount > 10_000_000:
            raise ValueError
    except ValueError:
        flash("Enter a valid budget amount.", "error")
        return redirect(url_for("dashboard", month=month))
    db = get_db()
    db.execute(
        "INSERT INTO budgets (user_id, month, amount) VALUES (?, ?, ?) "
        "ON CONFLICT(user_id, month) DO UPDATE SET amount = excluded.amount",
        (session["user_id"], month, amount))
    db.commit()
    flash(f"Budget for {month_label(month)} saved.", "success")
    return redirect(url_for("dashboard", month=month))


# --------------------------------------------------------------------------
# Expense CRUD
# --------------------------------------------------------------------------
@app.route("/expenses")
@login_required
def expenses():
    rows, filters = filtered_expenses(session["user_id"], request.args)
    total = sum(r["amount"] for r in rows)
    return render_template("expenses.html", expenses=rows, filters=filters, total=total)


@app.route("/expenses/add", methods=["GET", "POST"])
@login_required
def add_expense():
    if request.method == "POST":
        data, error = validate_expense(request.form)
        if error:
            flash(error, "error")
            return render_template("expense_form.html", expense=request.form, mode="add")
        db = get_db()
        db.execute(
            "INSERT INTO expenses (user_id, title, amount, category, spent_on, note) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (session["user_id"], data["title"], data["amount"], data["category"],
             data["spent_on"], data["note"]))
        db.commit()
        flash("Expense added.", "success")
        return redirect(url_for("expenses", month=data["spent_on"][:7]))
    return render_template("expense_form.html", expense={}, mode="add")


@app.route("/expenses/<int:expense_id>/edit", methods=["GET", "POST"])
@login_required
def edit_expense(expense_id):
    db = get_db()
    row = db.execute("SELECT * FROM expenses WHERE id = ? AND user_id = ?",
                     (expense_id, session["user_id"])).fetchone()
    if row is None:
        abort(404)
    if request.method == "POST":
        data, error = validate_expense(request.form)
        if error:
            flash(error, "error")
            return render_template("expense_form.html", expense=request.form,
                                   mode="edit", expense_id=expense_id)
        db.execute(
            "UPDATE expenses SET title = ?, amount = ?, category = ?, spent_on = ?, note = ? "
            "WHERE id = ? AND user_id = ?",
            (data["title"], data["amount"], data["category"], data["spent_on"],
             data["note"], expense_id, session["user_id"]))
        db.commit()
        flash("Expense updated.", "success")
        return redirect(url_for("expenses", month=data["spent_on"][:7]))
    return render_template("expense_form.html", expense=dict(row), mode="edit",
                           expense_id=expense_id)


@app.route("/expenses/<int:expense_id>/delete", methods=["POST"])
@login_required
def delete_expense(expense_id):
    db = get_db()
    cur = db.execute("DELETE FROM expenses WHERE id = ? AND user_id = ?",
                     (expense_id, session["user_id"]))
    db.commit()
    if cur.rowcount == 0:
        abort(404)
    flash("Expense deleted.", "info")
    return redirect(request.referrer or url_for("expenses"))


@app.route("/export.csv")
@login_required
def export_csv():
    rows, _ = filtered_expenses(session["user_id"], request.args)
    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(["Date", "Title", "Category", "Amount (INR)", "Note"])
    for r in rows:
        # prefix risky leading characters so spreadsheets don't run them as formulas
        def safe(v):
            return "'" + v if v and v[0] in "=+-@" else v
        writer.writerow([r["spent_on"], safe(r["title"]), r["category"],
                         f"{r['amount']:.2f}", safe(r["note"] or "")])
    return Response(buf.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition": "attachment; filename=expenses.csv"})


# --------------------------------------------------------------------------
# Error pages
# --------------------------------------------------------------------------
@app.errorhandler(404)
def not_found(_e):
    return render_template("error.html", code=404, message="Page not found."), 404


@app.errorhandler(400)
def bad_request(e):
    return render_template("error.html", code=400,
                           message=getattr(e, "description", "Bad request.")), 400


with app.app_context():
    init_db()

if __name__ == "__main__":
    app.run(debug=os.environ.get("FLASK_DEBUG") == "1")
