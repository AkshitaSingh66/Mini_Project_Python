"""Automated tests for the Student Expense Tracker. Run:  python -m unittest -v"""
import os
import re
import tempfile
import unittest
from datetime import date

import app as tracker


class TrackerTests(unittest.TestCase):
    def setUp(self):
        self.db_fd, self.db_path = tempfile.mkstemp(suffix=".db")
        tracker.app.config.update(DATABASE=self.db_path, TESTING=True)
        with tracker.app.app_context():
            tracker.init_db()
        self.c = tracker.app.test_client()

    def tearDown(self):
        os.close(self.db_fd)
        os.unlink(self.db_path)

    # helpers ---------------------------------------------------------
    def token(self, url="/login"):
        html = self.c.get(url).get_data(as_text=True)
        return re.search(r'name="_csrf" value="([^"]+)"', html).group(1)

    def register(self, user="alice", pw="secret1"):
        return self.c.post("/register", data={"_csrf": self.token("/register"),
                           "username": user, "password": pw, "confirm": pw},
                           follow_redirects=True)

    def login(self, user="alice", pw="secret1"):
        return self.c.post("/login", data={"_csrf": self.token(), "username": user,
                           "password": pw}, follow_redirects=True)

    def add(self, title="Lunch", amount="120.50", category="Food", spent_on=None, note=""):
        spent_on = spent_on or date.today().isoformat()
        return self.c.post("/expenses/add", data={"_csrf": self.token("/expenses/add"),
                           "title": title, "amount": amount, "category": category,
                           "spent_on": spent_on, "note": note}, follow_redirects=True)

    # tests -----------------------------------------------------------
    def test_login_required(self):
        r = self.c.get("/dashboard")
        self.assertEqual(r.status_code, 302)
        self.assertIn("/login", r.headers["Location"])

    def test_register_and_login(self):
        self.assertIn(b"Account created", self.register().data)
        self.assertIn(b"Spent this month", self.login().data)

    def test_duplicate_and_weak_registration(self):
        self.register()
        self.assertIn(b"already taken", self.register().data)
        r = self.c.post("/register", data={"_csrf": self.token("/register"), "username": "bob",
                        "password": "123", "confirm": "123"})
        self.assertIn(b"at least 6", r.data)

    def test_wrong_password(self):
        self.register()
        self.assertIn(b"Invalid username or password", self.login(pw="wrong").data)

    def test_csrf_blocks_post(self):
        r = self.c.post("/login", data={"username": "a", "password": "b"})
        self.assertEqual(r.status_code, 400)

    def test_add_edit_delete_expense(self):
        self.register(); self.login()
        self.assertIn(b"Expense added", self.add().data)
        page = self.c.get("/expenses").get_data(as_text=True)
        self.assertIn("Lunch", page)
        self.assertIn("120.50", page)

        eid = int(re.search(r"/expenses/(\d+)/edit", page).group(1))
        r = self.c.post(f"/expenses/{eid}/edit", data={
            "_csrf": self.token(f"/expenses/{eid}/edit"), "title": "Dinner", "amount": "200",
            "category": "Food", "spent_on": date.today().isoformat(), "note": ""},
            follow_redirects=True)
        self.assertIn(b"Expense updated", r.data)
        self.assertIn(b"Dinner", r.data)

        r = self.c.post(f"/expenses/{eid}/delete", data={"_csrf": self.token("/expenses")},
                        follow_redirects=True)
        self.assertIn(b"Expense deleted", r.data)
        self.assertNotIn(b"Dinner", r.data)

    def test_validation(self):
        self.register(); self.login()
        self.assertIn(b"Amount must be", self.add(amount="abc").data)
        self.assertIn(b"greater than 0", self.add(amount="-5").data)
        self.assertIn(b"valid category", self.add(category="Hacking").data)
        self.assertIn(b"valid date", self.add(spent_on="2026-13-45").data)

    def test_users_cannot_touch_each_others_data(self):
        self.register("alice"); self.login("alice"); self.add("Secret")
        eid = int(re.search(r"/expenses/(\d+)/edit",
                  self.c.get("/expenses").get_data(as_text=True)).group(1))
        self.c.post("/logout", data={"_csrf": self.token("/expenses")})
        self.register("bob"); self.login("bob")
        self.assertEqual(self.c.get(f"/expenses/{eid}/edit").status_code, 404)
        r = self.c.post(f"/expenses/{eid}/delete", data={"_csrf": self.token("/expenses")})
        self.assertEqual(r.status_code, 404)
        self.assertNotIn(b"Secret", self.c.get("/expenses").data)

    def test_budget_and_dashboard(self):
        self.register(); self.login(); self.add(amount="300")
        month = date.today().strftime("%Y-%m")
        r = self.c.post("/budget", data={"_csrf": self.token("/dashboard"),
                        "month": month, "amount": "1000"}, follow_redirects=True)
        self.assertIn(b"Budget for", r.data)
        self.assertIn(b"700.00", r.data)       # remaining
        self.assertIn(b"30% used", r.data)

    def test_search_filter_and_csv(self):
        self.register(); self.login()
        self.add("Bus pass", "500", "Transport"); self.add("Pizza", "250", "Food")
        page = self.c.get("/expenses?category=Transport").get_data(as_text=True)
        self.assertIn("Bus pass", page); self.assertNotIn("Pizza", page)
        page = self.c.get("/expenses?q=piz").get_data(as_text=True)
        self.assertIn("Pizza", page); self.assertNotIn("Bus pass", page)
        r = self.c.get("/export.csv")
        self.assertEqual(r.mimetype, "text/csv")
        self.assertIn(b"Date,Title,Category,Amount (INR),Note", r.data)
        self.assertIn(b"Bus pass", r.data)

    def test_csv_formula_injection_neutralised(self):
        self.register(); self.login(); self.add("=HYPERLINK(1)", "10")
        self.assertIn(b"'=HYPERLINK(1)", self.c.get("/export.csv").data)

    def test_html_is_escaped(self):
        self.register(); self.login(); self.add("<script>alert(1)</script>", "10")
        page = self.c.get("/expenses").get_data(as_text=True)
        self.assertNotIn("<script>alert(1)</script>", page)
        self.assertIn("&lt;script&gt;", page)


if __name__ == "__main__":
    unittest.main()
