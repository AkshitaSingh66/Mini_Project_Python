# Student Expense Tracker

A Flask + SQLite web app for students to log expenses, set a monthly budget and see spending charts.

## Features
- Register / login (hashed passwords, CSRF protection)
- Add, edit, delete expenses (title, amount, category, date, note)
- Monthly budget with progress bar and remaining balance
- Dashboard: category doughnut chart + 6-month trend chart
- Search and filter by month / category, export to CSV

## Run it
```bash
pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:5000, register an account and start adding expenses.
The database file `expenses.db` is created automatically on first run.

## Run the tests
```bash
python -m unittest -v
```

## Notes
- Charts load Chart.js from a CDN, so they need an internet connection (all figures still show without it).
- Before deploying, set a strong secret key: `SECRET_KEY=some-long-random-string python app.py`
